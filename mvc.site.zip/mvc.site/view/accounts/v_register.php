<form id="register_form">
    <label for="username">Username: </label>
    <input name="username" id="username" type="text" placeholder="Username">

    <br><br>

    <label for="password">Password: </label>
    <input name="password" id="password" type="password" placeholder="Password">

    <br><br>

    <label for="email">Email: </label>
    <input name="email" id="email" type="text" placeholder="Email">

    <p><b>Rules:</b></p>
    <ul>
        <li>Fields should not be empty</li>
        <li>Minimal length is 3 symbols</li>
        <li>Maximal length is 24 symbols</li>
        <li>Minimal length for password is 8 symbols</li>
        <li>Username should not contain spaces</li>
    </ul>

    <button type="submit">Register</button>

    <p id="result"></p>
</form>