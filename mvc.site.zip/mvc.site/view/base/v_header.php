<?php
session_start();

use core\Bootstrap;
$__ = new Bootstrap();

$currentUser = $_SESSION['currentUser'] ?? [];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?=$title?></title>
    <link rel="stylesheet" href="<?=BASE_URL?>assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?=BASE_URL?>assets/css/main.css">
</head>
<body>
<header class="site-header">
    <div class="container d-flex justify-content-between align-items-center">
        <div class="logo">
            <div class="logo__title h3">Lesson site</div>
            <div class="logo__subtitle h6">About MVC</div>
        </div>
        <div class="account">
            <?php if (key_exists('username', $currentUser)) { ?>
                <div class="logo__title h3"><?= $currentUser['username'] ?></div>
                <div class="logo__subtitle h6"><?= $__->__($currentUser['role']) ?></div>
            <?php } else { ?>
                <div class="buttons">
                    <button type="button" class="btn btn-outline-light">
                        <a href="<?=BASE_URL?>accounts/login"><?= $__->__('Log in')?></a>
                    </button>
                    <button type="button" class="btn btn-danger">
                        <a href="<?=BASE_URL?>accounts/register"><?= $__->__('Register')?></a>
                    </button>
                </div>
            <?php } ?>
        </div>
    </div>
</header>