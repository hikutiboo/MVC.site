</main>
</div>
</div>
<footer class="site-footer">
    <div class="container">
        &copy; MVC site
    </div>
</footer>
</body>
</html>