<main>
    <h1><?=$viewData->getData('title')?></h1>
    <hr>
    <?=$viewData->getData('content')?>
</main>