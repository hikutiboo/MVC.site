<div class="row">
    <aside class="col col-12 col-md-3">
        <?=$viewData->getData('left')?>
    </aside>
    <main class="col col-12 col-md-9">
        <h1><?=$viewData->getData('title')?></h1>
        <hr>
        <?=$viewData->getData('content')?>
    </main>
</div>