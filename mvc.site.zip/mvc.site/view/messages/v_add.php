<?php
use core\Bootstrap;
$__ = new Bootstrap();
?>
<form method="post">
    <div>
        <label for="messageName"><?= $__->__('User Name') ?></label>
        <input id="messageName" name="name" value="<?= $fields['name'] ?>">
    </div>
    <div>
        <label for="messageName"><?= $__->__('Title') ?></label>
        <input id="messageName" name="title" value="<?= $fields['title'] ?>">
    </div>
    <div>
        <label for="messageId"><?= $__->__('Message') ?></label>
        <textarea type="text" name="message" id="messageId"><?= $fields['message'] ?></textarea>
    </div>

    <input name="submit" value="<?= $__->__('Save') ?>" type="submit">
</form>
<div>
    <? foreach($validateErrors as $error): ?>
        <p><?=$error?></p>
    <? endforeach; ?>
</div>