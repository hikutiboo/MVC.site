<?php
use core\Bootstrap;
$__ = new Bootstrap();
?>
<?php if ($successText): ?>
    <div class="alert alert-success" role="alert">
        <?= $__->__('The message has been successfully added!') ?>
    </div>
<?php endif; ?>
<ul>
    <?php foreach ($messages as $message): ?>
    <li>
        <label><strong><?= $__->__('Message id') ?>:</strong></label><em><?= $message['id'] ?></em><br>
        <label><strong><?= $__->__('User Name') ?>:</strong></label><em><?= $message['name'] ?></em><br>
        <label><strong><?= $__->__('Title') ?>:</strong></label><em><?= $message['title'] ?></em><br>
        <label><strong><?= $__->__('Message') ?>:</strong></label><em><?= $message['message'] ?></em><br>
        <label><strong><?= $__->__('Created At') ?>:</strong></label><em><?= $message['created_at'] ?></em><br>
        <hr>
    </li>
    <?php endforeach; ?>
</ul>
