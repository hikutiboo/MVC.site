<main>
	<h1><?= $title ?></h1>
	<div class="alert alert-warning">
		<p>Page not found.</p>
		<p>Start from <a href="<?=BASE_URL?>">main page</a></p>
	</div>
</main>