<?php

namespace Controller;

class Controller
{
    private $viewData = [];
    private string $title = '';
}