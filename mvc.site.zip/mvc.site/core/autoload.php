<?php

spl_autoload_register(function ($path) {
    include_once('./'.str_replace('\\', DIRECTORY_SEPARATOR , $path).'.php');
});