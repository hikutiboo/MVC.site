<?php
declare(strict_types=1);

namespace core;

class Arr
{
    public function extractFields(array $target, array $fields): array {
        $arrayResult = [];

        foreach ($fields as $field) {
            $arrayResult[$field] = !is_null($target[$field])?trim($target[$field]):'';
        }

        return $arrayResult;
    }
}
