<?php
session_start();

include_once('core/autoload.php');
include_once('init.php');

use core\System;
$system = new System();

/* @var string $left
 * @var string $title
 * @var string $content
 */

$left = '';
    
$title = $content = 'Error 404';

$uri = $_SERVER['REQUEST_URI'];
$badUrl = BASE_URL . 'index.php';

if(strpos($uri, $badUrl) === 0){
    $cname = 'errors/e404';
} else {
    $routes = include('routes.php');
    $url = $_GET['mvcsystemurl'] ?? '';

    $routerRes = $system->parseUrl($url, $routes);
    $cname = $routerRes['controller'];

    $urlLen = strlen($url);

    if($urlLen > 0 && $url[$urlLen - 1] == '/'){
        $url = substr($url, 0, $urlLen - 1);
    }
}


/** @var string $path */
$path = "controller/$cname.php";
include_once($path);

