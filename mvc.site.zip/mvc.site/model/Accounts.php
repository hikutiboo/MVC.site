<?php
namespace model;

class Accounts
{

}