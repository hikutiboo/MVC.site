<?php
declare(strict_types=1);
/**
 * @by ProfStep, inc. 28.12.2020
 * @website: https://profstep.com
 **/

const HOST = 'http://mvc.site';
const BASE_URL = '/';

const DB_HOST = 'localhost';
const DB_DATABASE_NAME = 'mvc';
const DB_USER = 'root';
const DB_PASS = '';