<?php

use core\Bootstrap;
use core\DBAdapter;
use core\RenderHTMLPage;
use model\Messages;

$__ = new Bootstrap();
$db = new DBAdapter();
$render = new RenderHTMLPage();
$messages = new Messages();

$title = $__->__('Chat List');
$messages = $messages->getMessages($db->getConnection());

$successText = false;
if (isset($_SESSION['is_message_added']) && $_SESSION['is_message_added']) {
    $successText = true;
    unset($_SESSION['is_message_added']);
}

$render->renderHTML(['view/messages/v_index.php']);