<?php

use core\Arr;
use core\Bootstrap;
use core\DBAdapter;
use model\Messages;

$__ = new Bootstrap();
$arr = new Arr();
$db = new DBAdapter();
$messages = new Messages();

$title = $__->__('Add message');

$fieldsNotCleaned = $_POST;
$neededFieldsArray = ['name', 'title', 'message'];

/** extract */
$fields = $arr ->extractFields($_POST, $neededFieldsArray);
/**  validate */
$validateErrors = $_POST?$messages->messagesValidate($fields):[];
if(empty($validateErrors) and count($_POST)) {
    $result = $messages->setMessage($db->getConnection(), $fields);
    $_SESSION['is_message_added'] = $result;
    header('Location: ' . HOST . BASE_URL);
    exit;
}
include('view/base/v_header.php');
include('view/base/v_content.php');
include('view/messages/v_add.php');
include('view/base/v_footer.php');





