<?php

use core\Bootstrap;
$__ = new Bootstrap();

$title = $__->__('Register');

include('view/base/v_header.php');
include('view/base/v_content.php');
include('view/base/v_footer.php');